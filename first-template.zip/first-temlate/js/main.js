document.addEventListener('DOMContentLoaded', function() {
    require('./vendor/slick.min');

    
    require('./components/js-connect');
    require('./components/header');
});
